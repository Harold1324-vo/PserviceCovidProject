package com.example.pservicecovid;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

public class MainActivity extends AppCompatActivity {
    ImageSwitcher imageSwitcher;
    Button button;
    int imageSwitcherimage[] = {R.drawable.normalidad, R.drawable.termometro, R.drawable.notificacion};
    int switcherImageLength = imageSwitcherimage.length;
    int counter = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSwitcher = findViewById(R.id.imagenes);
        button = findViewById(R.id.boton);
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView switcherImageView= new ImageView(getApplicationContext());
                switcherImageView.setLayoutParams(new FrameLayout.LayoutParams(ActionBar.LayoutParams.FILL_PARENT, ActionBar.LayoutParams.FILL_PARENT));
                switcherImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                switcherImageView.setImageResource(R.drawable.normalidad);
                return switcherImageView;
            }
        });

        Animation animation = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        Animation animation1 = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        imageSwitcher.setOutAnimation(animation);
        imageSwitcher.setOutAnimation(animation1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter++;
                if(counter == switcherImageLength){
                    counter = 0;
                    imageSwitcher.setImageResource(imageSwitcherimage[counter]);
                }else {
                    imageSwitcher.setImageResource(imageSwitcherimage[counter]);
                }
            }
        });

    }
}